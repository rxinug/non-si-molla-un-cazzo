#include "common.h"
#include "include.h"


// Private Variables
static volatile uint32_t Sys_Tick = 0;

// Local Functions Prototypes
static void InitSysTick(void);
void SysTick_Handler(void);
void Delay_SysTick(uint32_t SysTicks);

// Imported Assembly Function
extern void EXAM_FUNCTION_NAME(uint32_t VAR);

// Exported variables
volatile uint32_t VAR1;
volatile uint32_t VAR2;
volatile uint32_t VAR3;
volatile uint32_t VAR4;
uint32_t VETT1[VETT1_N]; // size: VETT1_N
uint32_t vett1_idx;
uint8_t VETT2[VETT2_M]; // size: VETT2_M
uint8_t vett2_idx;

// S245885 **********************************************************************

unsigned short SEQ[SEQ_N] = {7, 2, 9, 6, 11, 1, 9, 5, 7 ,4};
uint8_t CLASSIFICA[CLASSIFICA_M];
uint8_t score = 0;
uint8_t max_diff = 0;
uint8_t podio = 0;
uint8_t seq_idx = 0;
uint8_t seq_val_led;
uint8_t seq_val_time;
stato_partita stato = IN_CORSO;

// *******************************************************************************

int main(void) {
	
	// S245885 **********************************************************************
	
	// *******************************************************************************
	
	
  // Imperative Inits
  SystemInit();
  InitSysTick();

  /* VARIABLES INITIALIZATION */
  memset(VETT1, 0, sizeof(VETT1));
  memset(VETT2, 0, sizeof(VETT2));
  vett1_idx = vett2_idx = 0;
  VAR1 = VAR2 = VAR3 = VAR4 = 0;

  /* PERIPHERALS INITIALIZATION */
  LED_init();
  joystick_init();
	joystick_enable_all();
  // LCD_Initialization();
  // ADC_init();
  BUTTON_init(BUTTON_0, IRQ_PRIO_MEDIUM);
  BUTTON_init(BUTTON_1, IRQ_PRIO_MEDIUM);
  BUTTON_init(BUTTON_2, IRQ_PRIO_MEDIUM);

  // RIT WORKS WITH CLOCK = 100MHZ -> ONE INTERRUPT EVERY 50ms
  init_RIT(RIT_MS_TO_TICKS(RIT_PERIOD_MS));
  enable_RIT();

  /* ENTER LOW-POWER MODE */
  LPC_SC->PCON |= 0x1;         // PM0=1
  LPC_SC->PCON &= 0xFFFFFFFFD; // PM1=0
	
	// all'avvio il gioco inizia in automatico

/* ============================================================
 *   API TIMER AD ALTO LIVELLO - configura E avvia gi�
 *   il timer, non � necessario chiamare enable_timer() separatamente.
 *   La "frequenza di interruzione" pu� essere espressa in ms o in Hz.
 *
 *   Helper di durata (-> ms): SECONDS(s), MINUTES(m), HOURS(h)
 *   es. timer_single_ms(TIMER_0, MINUTES(2), TIM_PRIO_HIGH, cb);
 *
 *   Prescaler: le funzioni *_ms ne selezionano automaticamente uno
 *   quando il valore � troppo grande per rientrare nel contatore a 32 bit
 *   (>~171800 ms a 25 MHz), cos� da poter passare direttamente
 *   durate lunghe come HOURS(1).
 * ============================================================ */

  /* --- Singolo impulso (Single-shot): scatta una sola volta dopo un ritardo --- */
  // timer_single_ms(TIMER_0, SECONDS(1), TIM_PRIO_HIGH, timer0_callback);
  // // Scatta dopo 1s, singolo impulso
  // timer_single_ms(TIMER_0, MINUTES(2), TIM_PRIO_HIGH, timer0_callback);
  // // Scatta dopo 2 minuti, singolo impulso
  // timer_single_ms(TIMER_0, HOURS(1), TIM_PRIO_HIGH, timer0_callback);
  // // Scatta dopo 1 ora, singolo impulso
  // timer_single_hz(TIMER_0, KHZ(1), TIM_PRIO_HIGH, timer0_callback);
  // // Scatta a una frequenza di 1 KHz
  // timer_single_nointr_ms(TIMER_0, SECONDS(1));
  // // Solo hardware, senza IRQ (interruzione)

  /* --- Ripetitivo INFINITO --- */
  // timer_periodic_ms(TIMER_1, SECONDS(1), TIM_PRIO_HIGH, timer1_callback);
  // // Scatta ogni 1s
  // timer_periodic_hz(TIMER_1, KHZ(1), TIM_PRIO_HIGH, timer1_callback);
  // // Scatta con frequenza di 1 KHz
  // timer_periodic_hz(TIMER_1, MHZ(1), TIM_PRIO_HIGH, timer1_callback);
  // // Scatta con frequenza di 1 MHz
  // timer_periodic_nointr_ms(TIMER_1, MINUTES(1));
  // // Solo hardware, senza IRQ (interruzione)

  /* --- Ripetitivo FINITO: viene eseguito solo per la durata di turn_off_after_ms --- */

  // timer_periodic_finite_ms(TIMER_1, SECONDS(1), SECONDS(10), TIM_PRIO_HIGH, timer1_callback);
  // // Tick ogni 1s per un totale di 10s
  // timer_periodic_finite_hz(TIMER_1, KHZ(1), MINUTES(1), TIM_PRIO_HIGH, timer1_callback);
  // // 1 kHz per 1 minuto
  // timer_periodic_finite_nointr_ms(TIMER_1, SECONDS(1), SECONDS(10));
  // // Si arresta automaticamente, nessuna callback utente

  /* --- PWM (duty cycle + periodo), l'interruzione guida la callback --- */
  // timer_pwm_ms(TIMER_2, 0.25, SECONDS(1), TIM_PRIO_HIGH, timer2_callback);
  // // Duty cycle al 25%, periodo di 1s
  // timer_pwm_finite_hz(TIMER_3, 0.25, KHZ(1), SECONDS(10), TIM_PRIO_HIGH, timer3_callback);
  // // Duty cycle al 25%, 1 kHz, si disabilita dopo 10s

  /* Macro di frequenza: KHZ / MHZ / GHZ. Un timer reale si attesta
   * intorno al clock di 25 MHz, quindi GHZ() � utile solo per esprimere
   * la macro stessa, ad es. GHZ(1) == 1000000000. */

  /* ============================================================
   *   DESCRITTORE SEMPLICE BASATO SU CAMPI: imposta un singolo
   *   valore nominale per comportamento invece di applicare l'operatore OR sui flag.
   *   timer_easy_setup() verifica la combinazione e restituisce
   *   un tipo tmr_status_t (TMR_OK == 0).
   *     shot = TMR_SHOT_SINGLE / TMR_SHOT_REPEAT
   *     run  = TMR_RUN_INFINITE / TMR_RUN_FINITE   (solo se REPEAT)
   *     irq  = TMR_IRQ_OFF / TMR_IRQ_ON
   *     pwm  = TMR_PWM_OFF / TMR_PWM_ON  (pwm_on = frazione di ON, es. 0.5)
   * ============================================================ */
  // Scatta UNA VOLTA dopo 1s, con interruzione:
  /*
  timer_easy_config_t ecfg = {0};
  ecfg.timer_n      = TIMER_0;
  ecfg.shot         = TMR_SHOT_SINGLE;
  ecfg.run          = TMR_RUN_INFINITE;          // ignorato in caso di SINGLE
  ecfg.irq          = TMR_IRQ_ON;
  ecfg.pwm          = TMR_PWM_OFF;
  ecfg.period_ticks = TIM_MS_TO_TICKS_SIMPLE(SECONDS(1));
  ecfg.prio         = TIM_PRIO_HIGH;
  ecfg.callback     = timer0_callback;
  timer_easy_setup(&ecfg);
  */

  // PWM al 50%, periodo di 1s, ripetitivo per 10s, con interruzione:
  /*
  timer_easy_config_t pcfg = {0};
  pcfg.timer_n      = TIMER_2;
  pcfg.shot         = TMR_SHOT_REPEAT;
  pcfg.run          = TMR_RUN_FINITE;            // si arresta dopo run_for_ms
  pcfg.irq          = TMR_IRQ_ON;
  pcfg.pwm          = TMR_PWM_ON;
  pcfg.period_ticks = TIM_MS_TO_TICKS_SIMPLE(SECONDS(1));
  pcfg.pwm_on       = 0.5f;                      // duty cycle = 0.5 * period_ticks
  pcfg.run_for_ms   = SECONDS(10);
  pcfg.prio         = TIM_PRIO_HIGH;
  pcfg.callback     = timer2_callback;
  timer_easy_setup(&pcfg);
  */

  while (1) {
    __ASM("wfi");
  }
}

/*
Shortcuts:
- Ctrl+H : replace
- F3 : find all occurrences
*/

/* Initialize SysTick using CMSIS Core_CM4 function */
static void InitSysTick(void) {
  SysTick_Config(SystemFrequency / 1000U); /* Configure the SysTick timer */
}
/* SysTick Interrupt Handler */
void SysTick_Handler(void) { Sys_Tick++; /* increment timer */ }
/* Delay Function based on SysTick Counter */
void Delay_SysTick(uint32_t SysTicks) {
  uint32_t DelayTimer_SysTick = Sys_GetTick() + SysTicks; /* Get End Tick */
  while (Sys_GetTick() < DelayTimer_SysTick)
    ; /* wait for timer */
}
/*Get Current Elapsed Ticks*/
uint32_t Sys_GetTick(void) { return Sys_Tick; }