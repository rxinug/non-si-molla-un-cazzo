    AREA    my_asm_function, CODE, READONLY
    THUMB
    PRESERVE8

    EXPORT  updateRank

; ------------------------------------------------------------------
; Parametri (AAPCS):
;   R0 = valore da inserire (es. SCORE)               [uint8_t]
;   R1 = indirizzo base del vettore (es. CLASSIFICA)  [uint8_t*]
; Return:
;   R0 = posizione (indice) in cui il valore e' stato inserito
;        (255 / ultima posizione se il valore e' il piu' basso di tutti
;         e non trova mai un elemento minore -- CUSTOMIZE il "not_found")
; ------------------------------------------------------------------

updateRank FUNCTION
 
; Parameters:
;   R0 = score
;   R1 = ptr classifica
;   R2 = ptr max_diff
;   R3 = ptr podio
; 
; Returns:
;   R0 = position

	PUSH     {r4-r11, LR}

    MOV     r4, #0             ; r4 = indice di scansione, parte da 0
	
	; Parametri (AAPCS):
;   R0 = valore da inserire (es. SCORE)               [uint8_t]
;   R1 = indirizzo base del vettore (es. CLASSIFICA)  [uint8_t*]
; Return:
;   R0 = posizione (indice) in cui il valore e' stato inserito
;        (255 / ultima posizione se il valore e' il piu' basso di tutti
;         e non trova mai un elemento minore -- CUSTOMIZE il "not_found")

; ============================================================
; FASE 1: cerca la posizione + inserimento immediato
; ============================================================
find_pos
    CMP     r4, #256           
    BGE     not_found         

    LDRB    r5, [r1, r4]
    CMP     r0, r5
    STRBGT  r0, [r1, r4]       ; <-- CUSTOMIZE: STRBGT/STRHGT/STRGT
    MOVGT   r9, r4             ; salva la posizione trovata (per il return)
    BGT     shift_start        ; trovato: passa subito alla fase di shift

    ADD     r4, r4, #1
    B       find_pos

; ============================================================
; FASE 2: shift "a passamano" -- r5 e' gia' pronto dalla fase 1
;         (contiene il valore spodestato da r4, appena scritto sopra)
; ============================================================
shift_start
    ADD     r4, r4, #1          ; passa alla posizione successiva

shift_loop
    CMP     r4, #256            ; <-- CUSTOMIZE: stessa dimensione di sopra
    BGE     end_shift

    LDRB    r6, [r1, r4]        ; <-- CUSTOMIZE: valore attualmente presente
    STRB    r5, [r1, r4]        ; <-- CUSTOMIZE: scrivi il valore "portato" dal giro precedente

    MOV     r5, r6              ; aggiorna la "mano" col nuovo valore da portare
    ADD     r4, r4, #1
    B       shift_loop

end_shift



  MOV     r4, #0
    MOV     r7, #0               ; r7 = max_diff accumulato
    LDRB    r10, [r1, r4]        ; <-- CUSTOMIZE: LDRB/LDRH/LDR, valore iniziale = vettore[0]

md_loop
    ADD     r4, r4, #1
    CMP     r4, #256             ; <-- CUSTOMIZE: stessa dimensione di sopra
    BGE     md_end

    LDRB    r6, [r1, r4]         ; <-- CUSTOMIZE: r6 = vettore[r4] (valore corrente)
    SUB     r11, r10, r6         ; differenza = precedente - corrente
    CMP     r11, r7
    MOVGT   r7, r11              ; aggiorna il massimo se questa differenza e' piu' grande

    MOV     r10, r6              ; il corrente diventa il "precedente" per il prossimo giro
    B       md_loop

md_end
    STRB    r7, [r2]             ; <-- CUSTOMIZE: STRB/STRH/STR, scrivi *max_diff (R2 mai toccato prima)




    MOV     r0, r9               ; return: posizione raggiunta
	
	; mov r8, r3 ; r8 contiene l'indirizzo di podio
		
	mov r8, #0
	CMP r9, #3
	movlt r8, #1	
	
	strb r8, [r3]

    B       exit

not_found
    MOV     r0, #255         
exit
    POP     {r4-r11, PC}
    ENDFUNC

    END
