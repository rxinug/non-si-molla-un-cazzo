./output/lib_timer.o: timer\lib_timer.c timer\..\common.h timer\timer.h \
  timer\..\joystick\joystick.h timer\..\joystick\..\common.h \
  timer\..\joystick\..\led\led.h \
  C:\Users\gunix\AppData\Local\Arm\Packs\Keil\LPC1700_DFP\2.7.2\Device\Include\LPC17xx.h \
  C:\Users\gunix\AppData\Local\Arm\Packs\ARM\CMSIS\6.3.0\CMSIS\Core\Include\core_cm3.h \
  C:\Users\gunix\AppData\Local\Arm\Packs\Keil\LPC1700_DFP\2.7.2\Device\Include\system_LPC17xx.h \
  timer\..\led\led.h
