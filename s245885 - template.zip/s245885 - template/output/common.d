./output/common.o: common.c common.h
