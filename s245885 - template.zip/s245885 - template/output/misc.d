.\output\misc.o: misc.s
