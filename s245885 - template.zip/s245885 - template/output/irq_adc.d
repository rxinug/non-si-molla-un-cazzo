./output/irq_adc.o: adc\IRQ_adc.c adc\..\include.h \
  C:\Users\gunix\AppData\Local\Arm\Packs\Keil\LPC1700_DFP\2.7.2\Device\Include\LPC17xx.h \
  C:\Users\gunix\AppData\Local\Arm\Packs\ARM\CMSIS\6.3.0\CMSIS\Core\Include\core_cm3.h \
  C:\Users\gunix\AppData\Local\Arm\Packs\Keil\LPC1700_DFP\2.7.2\Device\Include\system_LPC17xx.h \
  adc\..\led\led.h adc\..\button_EXINT\button.h \
  adc\..\button_EXINT\..\common.h adc\..\button_EXINT\..\led\led.h \
  adc\..\timer\timer.h adc\..\timer\..\joystick\joystick.h \
  adc\..\timer\..\joystick\..\common.h \
  adc\..\timer\..\joystick\..\led\led.h adc\..\timer\..\led\led.h \
  adc\..\joystick\joystick.h adc\..\RIT\RIT.h adc\..\RIT\..\led\led.h \
  adc\..\RIT\..\timer\timer.h adc\..\GLCD\AsciiLib.h adc\..\GLCD\GLCD.h \
  adc\..\adc\adc.h adc\adc.h
