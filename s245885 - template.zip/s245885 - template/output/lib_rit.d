./output/lib_rit.o: RIT\lib_RIT.c RIT\..\button_EXINT\button.h \
  RIT\..\button_EXINT\..\common.h RIT\..\button_EXINT\..\led\led.h \
  C:\Users\gunix\AppData\Local\Arm\Packs\Keil\LPC1700_DFP\2.7.2\Device\Include\LPC17xx.h \
  C:\Users\gunix\AppData\Local\Arm\Packs\ARM\CMSIS\6.3.0\CMSIS\Core\Include\core_cm3.h \
  C:\Users\gunix\AppData\Local\Arm\Packs\Keil\LPC1700_DFP\2.7.2\Device\Include\system_LPC17xx.h \
  RIT\..\joystick\joystick.h RIT\..\joystick\..\common.h \
  RIT\..\joystick\..\led\led.h RIT\RIT.h RIT\..\led\led.h \
  RIT\..\timer\timer.h RIT\..\timer\..\joystick\joystick.h \
  RIT\..\timer\..\led\led.h
