./output/sample.o: sample.c common.h include.h \
  C:\Users\gunix\AppData\Local\Arm\Packs\Keil\LPC1700_DFP\2.7.2\Device\Include\LPC17xx.h \
  C:\Users\gunix\AppData\Local\Arm\Packs\ARM\CMSIS\6.3.0\CMSIS\Core\Include\core_cm3.h \
  C:\Users\gunix\AppData\Local\Arm\Packs\Keil\LPC1700_DFP\2.7.2\Device\Include\system_LPC17xx.h \
  led\led.h button_EXINT\button.h button_EXINT\..\common.h \
  button_EXINT\..\led\led.h timer\timer.h timer\..\joystick\joystick.h \
  timer\..\joystick\..\common.h timer\..\joystick\..\led\led.h \
  timer\..\led\led.h joystick\joystick.h RIT\RIT.h RIT\..\led\led.h \
  RIT\..\timer\timer.h GLCD\AsciiLib.h GLCD\GLCD.h adc\adc.h
