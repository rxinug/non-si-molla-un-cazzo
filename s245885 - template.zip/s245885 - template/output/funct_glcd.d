./output/funct_glcd.o: GLCD\funct_glcd.c GLCD\AsciiLib.h GLCD\GLCD.h \
  C:\Users\gunix\AppData\Local\Arm\Packs\Keil\LPC1700_DFP\2.7.2\Device\Include\LPC17xx.h \
  C:\Users\gunix\AppData\Local\Arm\Packs\ARM\CMSIS\6.3.0\CMSIS\Core\Include\core_cm3.h \
  C:\Users\gunix\AppData\Local\Arm\Packs\Keil\LPC1700_DFP\2.7.2\Device\Include\system_LPC17xx.h
