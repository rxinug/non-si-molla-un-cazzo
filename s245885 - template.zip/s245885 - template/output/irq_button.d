./output/irq_button.o: button_EXINT\IRQ_button.c button_EXINT\..\common.h \
  button_EXINT\..\led\led.h button_EXINT\..\timer\timer.h \
  button_EXINT\..\timer\..\joystick\joystick.h \
  button_EXINT\..\timer\..\joystick\..\common.h \
  button_EXINT\..\timer\..\joystick\..\led\led.h \
  C:\Users\gunix\AppData\Local\Arm\Packs\Keil\LPC1700_DFP\2.7.2\Device\Include\LPC17xx.h \
  C:\Users\gunix\AppData\Local\Arm\Packs\ARM\CMSIS\6.3.0\CMSIS\Core\Include\core_cm3.h \
  C:\Users\gunix\AppData\Local\Arm\Packs\Keil\LPC1700_DFP\2.7.2\Device\Include\system_LPC17xx.h \
  button_EXINT\..\timer\..\led\led.h button_EXINT\button.h
